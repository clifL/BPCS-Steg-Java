import java.util.*;
import java.io.*;

public class FileFinder {
    private List<Integer> bitForm;
    private List<Character> text;
    private byte[] byteForm;

    public FileFinder(List<Segment> segments) { //if type == true, then will read as text
        bitForm = new ArrayList<Integer>();

        int q = 0; //counter
        for(Segment seg : segments) {
            int[][] temp = seg.getSegArr();

            if(temp[0][0] == 1) { //conjugate again to get back
                for(int r = 0; r < 8; r++) for(int c = 0; c < 8; c++) temp[r][c] ^= ((r % 2 == 0)? ((c % 2 == 0)? 0 : 1) : ((c % 2 == 0)? 1 : 0));
            }

            for(int j = 0; j < 8; j++) for(int k = (j == 0)? 1 : 0; k < 8; k++) bitForm.add(temp[j][k]);
        } //read stuff into bitForm
    }

    public void constructFile() throws IOException {
        int length = getLength();
        String extension = getExtension();

        System.out.println("File size: " + length + " bytes");
        System.out.println("File extension: " + extension);

        byteForm = new byte[length];

        for(int m = 96; m < 96 + length * 8; m += 8) {
            int store = 0;
            for(int n = 0; n < 8; n++) store += bitForm.get(m + n) << (7 - n);
            byteForm[(m - 96) / 8] = (byte) (store - 128);
        }

        FileOutputStream fos = new FileOutputStream("ExtractedPayloads/Extracted" + extension);
        fos.write(byteForm);
        fos.close();
    }

    public int getLength() { //obtains fileLength from header
        int fileLength = 0;
        for(int m = 0; m < 32; m++) fileLength += bitForm.get(m) << (31 - m);
        return fileLength;
    }

    public String getExtension() { //obtains fileExtension from header
        String fileExtension = "";
        boolean startReading = false;
        for(int m = 32; m < 96; m += 8) {
            char store = 0;
            for(int n = 0; n < 8; n++) store += bitForm.get(m + n) << (7 - n);
            if(store == '.') startReading = true;
            if(startReading) fileExtension += store;
        }
        return fileExtension;
    }
}
