public interface Chunk {
    int getBorder();
    boolean isComplex();
}
