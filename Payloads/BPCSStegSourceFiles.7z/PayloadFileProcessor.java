import java.util.*;
import java.io.*;

public class PayloadFileProcessor {
    private int[] bitForm;
    private byte[] byteForm;
    private Block[] blocks;
    private String fileName;
    private int fileLength;

    public PayloadFileProcessor(String fileName) throws IOException, FileNotFoundException {
        File payload = new File(fileName);
        fileLength = (int) payload.length();
        this.fileName = fileName;

        FileInputStream fis = new FileInputStream(payload);

        byteForm = new byte[fileLength + 12];
        buildHeader(); //simply modifies payload byteForm header
        fis.read(byteForm, 12, (int) payload.length());

        bitify();
        blockify();
    }

    public PayloadFileProcessor() throws IOException, FileNotFoundException {
        this("Payload.txt");
    }

    public void buildHeader() {
        for(int k = 0; k < 4; k++) byteForm[k] = (byte) (((fileLength >> (24 - k * 8)) & 0xFF) - 128);
        //reads in the length of the file

        int j = 0;
        String fileExtension = fileName.substring(fileName.lastIndexOf(".")); //such as .docx
        for(int k = 12 - fileExtension.length(); k < 12; k++) byteForm[k] = (byte) (fileExtension.charAt(j++) - 128);
        //reads in the extension of the file
    }

    public void bitify() {
        int q = 0; //counter
        bitForm = new int[byteForm.length * 8];
        for(byte val : byteForm) for(int k = 0; k < 8; k++) bitForm[q++] = ((val + 128) >> (7 - k)) % 2; //converts each char into 8 bits
    }

    public void blockify() {
        int p = 0; //counter
        blocks = new Block[(int) Math.ceil(bitForm.length / 63.0)];
        for(int j = 0; j < bitForm.length; j += 63) {
            int[] feed = new int[64];
            for(int k = 1; (j + k - 1) < bitForm.length && k < 64; k++) feed[k] = bitForm[j + k - 1];
            blocks[p++] = new Block(feed);
        }
    }

    public int blockLength() {
        return blocks.length;
    }

    public Block getBlock(int i) {
        return blocks[i];
    }

    public int getNumOfConjugated() {
        int count = 0;
        for(Block block : blocks) if(block.getConjugated()) count++;
        return count;
    }
}
